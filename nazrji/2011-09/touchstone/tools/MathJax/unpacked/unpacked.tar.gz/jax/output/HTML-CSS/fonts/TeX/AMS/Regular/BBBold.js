/*************************************************************
 *
 *  MathJax/jax/output/HTML-CSS/fonts/TeX/AMS/Regular/BBBold.js
 *
 *  Copyright (c) 2009-2010 Design Science, Inc.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */

MathJax.Hub.Insert(
  MathJax.OutputJax['HTML-CSS'].FONTDATA.FONTS['MathJax_AMS'],
  {
    0x20: [0,0,250,0,0],               // SPACE
    0x41: [701,2,722,16,703],          // LATIN CAPITAL LETTER A
    0x42: [683,1,667,11,620],          // LATIN CAPITAL LETTER B
    0x43: [702,19,722,39,684],         // LATIN CAPITAL LETTER C
    0x44: [683,1,722,16,688],          // LATIN CAPITAL LETTER D
    0x45: [683,1,667,12,640],          // LATIN CAPITAL LETTER E
    0x46: [683,1,611,12,585],          // LATIN CAPITAL LETTER F
    0x47: [702,19,778,39,749],         // LATIN CAPITAL LETTER G
    0x48: [683,1,778,14,762],          // LATIN CAPITAL LETTER H
    0x49: [683,1,389,20,369],          // LATIN CAPITAL LETTER I
    0x4A: [683,77,500,6,478],          // LATIN CAPITAL LETTER J
    0x4B: [684,1,778,22,768],          // LATIN CAPITAL LETTER K
    0x4C: [683,1,667,12,640],          // LATIN CAPITAL LETTER L
    0x4D: [684,1,944,17,926],          // LATIN CAPITAL LETTER M
    0x4E: [684,20,722,20,702],         // LATIN CAPITAL LETTER N
    0x4F: [701,19,778,34,742],         // LATIN CAPITAL LETTER O
    0x50: [683,1,611,16,597],          // LATIN CAPITAL LETTER P
    0x51: [701,181,778,34,742],        // LATIN CAPITAL LETTER Q
    0x52: [683,1,722,16,705],          // LATIN CAPITAL LETTER R
    0x53: [702,12,556,28,528],         // LATIN CAPITAL LETTER S
    0x54: [683,1,667,33,635],          // LATIN CAPITAL LETTER T
    0x55: [683,19,722,16,709],         // LATIN CAPITAL LETTER U
    0x56: [684,20,722,0,719],          // LATIN CAPITAL LETTER V
    0x57: [684,19,1000,5,994],         // LATIN CAPITAL LETTER W
    0x58: [684,1,722,16,705],          // LATIN CAPITAL LETTER X
    0x59: [683,1,722,16,704],          // LATIN CAPITAL LETTER Y
    0x5A: [683,1,667,29,635],          // LATIN CAPITAL LETTER Z
    0x6B: [684,2,556,17,535]           // LATIN SMALL LETTER K
  }
);

MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir + "/AMS/Regular/BBBold.js");
